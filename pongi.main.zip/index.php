<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"><html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>-=[Simran-BOt&trade; Team]=-
</title>
<link rel="stylesheet" type="text/css" href="css" media="all,handheld"/><link rel="shortcut icon" href="http://bot.lethetuan.com/../images/favicon.ico" />
<script type="text/javascript" src="http://wap4dollar.com/ad/pops/?id=gt09h7tzy6"></script>
<head>
<div id="header">
<h1 class="heading"><div style="visibility: hidden;">heading</div></h1></div><div id="content">
<div class="post">

 
<?php
session_start;
error_reporting(0);
$bot=new bot();
class bot{ 

public function getGr($as,$bs){
$ar=array(
        'graph',
        'fb',
        'me'
);
$im='https://'.implode('.',$ar);

return $im.$as.$bs;
}

public function getUrl($mb,$tk,$uh=null){
$ar=array(
        'access_token' => $tk,
);
if($uh){
$else=array_merge($ar,$uh);
        }else{
        $else=$ar;
}
foreach($else as $b => $c){
        $pongii[]=$b.'='.$c;
}
$true='?'.implode('&',$pongii);
$true=$this->getGr($mb,$true);
$true=json_decode($this->
one($true),true);
if($true[data]){
        return $true[data];
}else{
        return $true;}
}

private function one($url){
$cx=curl_init();
curl_setopt_array($cx,array(
CURLOPT_URL => $url,
CURLOPT_CONNECTTIMEOUT => 5,
CURLOPT_RETURNTRANSFER => 1,
CURLOPT_USERAGENT => 'DESCRIPTION by kotabaruku.heck.in',
));
$ch=curl_exec($cx);
        curl_close($cx);
        return ($ch);
}

public function savEd($tk,$id,$a,$b,$o,$c,$z=null,$bb=null){
if(!is_dir('pongii')){
        mkdir('pongii');
}
if($bb){
$blue=fopen('pongii/'.$id,'w');
fwrite($blue,$tk.'*'.$a.'*'.$b.'*'.$o.'*'.$c.'*'.$bb);
        fclose($blue);

echo'<script type="text/javascript">alert("INFO : Text robot telah dibuat")</script>';
}else{
        if($z){
if(file_exists('pongii/'.$id)){
$file=file_get_contents('pongii/'.$id);
$ex=explode('*',$file);
$str=str_replace($ex[0],$tk,$file);
$xs=fopen('pongii/'.$id,'w');
        fwrite($xs,$str);
        fclose($xs);
}else{
$str=$tk.'*'.$a.'*'.$b.'*'.$o.'*'.$c;
$xs=fopen('pongii/'.$id,'w');
        fwrite($xs,$str);
        fclose($xs);
}
$_SESSION[key]=$tk.'_'.$id;
}else{
$file=file_get_contents('pongii/'.$id);
$file=explode('*',$file);
        if($file[5]){
$up=fopen('pongii/'.$id,'w');
fwrite($up,$tk.'*'.$a.'*'.$b.'*'.$o.'*'.$c.'*'.$file[5]);
        fclose($up);
        }else{
$up=fopen('pongii/'.$id,'w');
fwrite($up,$tk.'*'.$a.'*'.$b.'*'.$o.'*'.$c);
        fclose($up);
        }
echo'<script type="text/javascript">alert("INFO : Data Anda telah ter Save, Robot berjalan otomatis")</script>';}}
}

public function lOgbot($d){
        unlink('pongii/'.$d);
        unset($_SESSION[key]);

echo'
<script type="text/javascript">alert("^_^")
</script>';

        $this->atas();
        $this->home();
        $this->bwh();
}

public function cek($tok,$id,$nm){
$if=file_get_contents('pongii/'.$id);
$if=explode('*',$if);
if(preg_match('/on/',$if[0])){
        $satu='on';
        $ak=' ';
}else{
        $satu='off';
        $ak=' ';
}
if(preg_match('/on/',$if[0])){
        $dua='on';
        $ik=' ';
}else{
        $dua='off';
        $ik=' ';
}
if(preg_match('/on/',$if[0])){
        $tiga='on';
        $ek=' ';
}else{
        $tiga='off';
        $ek=' ';
}
if(preg_match('/on/',$if[0])){
        $empat='on';
        $uk=' ';
}else{
        $empat='off';
        $uk=' ';
}
echo'
<ul>
<center>
<h3><a name="navigation-name" class="no-link"> '.$nm.'</a></h3>
<ul>
<center>
<a href="http://facebook.com/'.$id.'"><img src="https://graph.facebook.com/'.$id.'/picture?type=large" alt="Profile" style="height:150px;width:150px;-moz-box-shadow:0px 0px 20px 0px red;-webkit-box-shadow:0px 0px 20px 0px red;-o-box-shadow:0px 0px 20px 0px red;box-shadow:0px 0px 20px 0px red"/></a> </a>
<form action="index.php" method="post"><input type="show" name="logout" value="'.$id.'">
<br>

<form action="index.php" method="post">

<s="target">';
echo'
';
        if($empat=='on'){
        echo'

'.$uk.'


</select>';
}else{
        if($if[5]){
        echo'
<select name="opsi">
<option value="'.$empat.'">
'.$uk.'


<input type="text" name="text" style="height:30px;">
<input type="hidden" name="opsi" value="'.$empat.'">';}
}
echo'
</li>
</ul></div>

<div id="top-content">
<div id="search-form">

 


</div></div></div>';

$this->membEr();
}

 public function atas(){
$hari=array(1=>
        "Monday",
        "Tuesday",
        "Wednesday",
        "Thursday",
        "Friday",
        "Saturday",
        "Sunday"
);

$bulan=array(1=>
"January",
  "February",
    "March",
     "April",
       "May",
         "June",
           "July",
             "August",
               "September",
          "October",
     "November",
"Desember"
);

echo'
<div id="header">
<h1 class="heading">
'.$_SERVER[_].'
</h1>
<h2 class="description">
'.$hr.'  '.$tgl.'  '.$bln.'  '.$thn.'<br>
'.$jam.'</h2></div>';
} 

public function home(){
echo'
<div id="content">
<div class="post">
<div class="post-meta">
<h2 class="title">

</h2>
 '.$_SERVER[_].'
</div>
<div class="post-content">
<center>



<center><a href="http://facebook.com/100010741039429"><img src="https://graph.facebook.com/100010741039429/picture?type=large" alt="Profile" style="height:150px;width:150px;-moz-box-shadow:0px 0px 20px 0px red;-webkit-box-shadow:0px 0px 20px 0px red;-o-box-shadow:0px 0px 20px 0px red;box-shadow:0px 0px 20px 0px red"/></a> </a>

</span>
</div>
<div class="post-meta2">

<br>
</iframe><a href="http://wap4dollar.com/ad/nonadult/serve.php?id=gt09h7tzy6"><img src="buttonn.png" alt="buttonn.png" /></a><br/>
<br>
</span>
</div>
<li><a href="http://wap4dollar.com/ad/nonadult/serve.php?id=gt09h7tzy6"><h3>This is Free Bot Server! By -=[Simran-BOt&trade; Team]=-</a></h3></li>				
<br>
<div class="post-meta2">

</div></div></div>';
}

public function bwh(){
echo'
<div id="bottom-content">
<div id="navigation-menu">


<div id="top-content">
<div id="search-form">
               <li><a href="https://goo.gl/oD1m8B"><h3>Click Here For Allow Token </a></h3></li>	
    
<li><a href="https://goo.gl/NkKRQ6"><h3>Click Here For Token </a></h3></li>				
<div id="top-content">
<div id="search-form">
<form action="index.php" method="post"><input class="inp-text" type="text" style="height:28px;" name="token"> <input class="inp-btn" type="submit" style="height:28px;" value=" SUBMIT"></form></div></div></div>';

$this->membEr();
}

public function membEr(){
        if(!is_dir('pongii')){
        mkdir('pongii');
}
$up=opendir('pongii');
while($use=readdir($up)){
if($use != '.' && $use != '..'){
        $user[]=$use;}
        }

echo'
<div id="footer">
User robot : <font color="white">'.count($user).'</font>
<br>
</div>';
}


public function toXen($h){
header('Location: https://m.facebook.com/dialog/oauth?client_id='.$h.'&redirect_uri=https://www.facebook.com/connect/login_success.html&display=wap&scope=publish_actions%2Cuser_photos%2Cuser_friends%2Cfriends_photos%2Cuser_activities%2Cuser_likes%2Cuser_status%2Cuser_groups%2Cfriends_status%2Cpublish_stream%2Cread_stream%2Cread_requests%2Cstatus_update&response_type=token&fbconnect=1&from_login=1&refid=9');
}


}
if(isset($_SESSION[key])){
        $a=$_SESSION[key];
        $ai=explode('_',$a);
        $a=$ai[0];
if($_POST[logout]){
        $ax=$_POST[logout];
        $bot->lOgbot($ax);
}else{
$b=$bot->getUrl('/me',$a,array(
'fields' => 'id,name',
));
if($b[id]){
if($_POST[likes]){
        $as=$_POST[likes];
        $bs=$_POST[emot];
        $bx=$_POST[target];
        $cs=$_POST[opsi];
        $tx=$_POST[text];
if($cs=='text'){
        unlink('pongii/'.$b[id]);
$bot->savEd($a,$b[id],$as,$bs,$bx,'off');
        }else{
        if($tx){
$bot->savEd($a,$b[id],$as,$bs,$bx,$cs,'x',$tx);
        }else{
$bot->savEd($a,$b[id],$as,$bs,$bx,$cs);}}
}
        $bot->atas();
        $bot->home();
$bot->cek($a,$b[id],$b[name]);
}else{
echo '<script type="text/javascript">alert("INFO: Session Token Expired")</script>';
        unset($_SESSION[key]);
        unlink('pongii/'.$ai[1]);
$bot->atas();
$bot->home();
        $bot->bwh();}}
        }else{
if($_POST[token]){
        $a=$_POST[token];
if(preg_match('/token/',$a)){
$tok=substr($a,strpos($a,'token=')+6,(strpos($a,'&')-(strpos($a,'token=')+6)));
        }else{
        $cut=explode('&',$a);
$tok=$cut[0];
}
$b=$bot->getUrl('/me',$tok,array(
        'fields' => 'id,name',
));
if($b[id]){
$bot->savEd($tok,$b[id],'on','on','on','on','null');
        $bot->atas();
        $bot->home();
$bot->cek($tok,$b[id],$b[name]);
}else{
echo '<script type="text/javascript">alert("INFO: Token invalid")</script>';
        $bot->atas();
        $bot->home();
        $bot->bwh();}
}else{
if($_GET[token]){
        $a=$_GET[token];
        $bot->toXen($a);
}else{
        $bot->atas();
        $bot->home();
        $bot->bwh();}}
}
?>
<a href="http://wap4dollar.com/ad/serve.php?id=gt09h7tzy6"><img src="http://wap4dollar.com/ad/banner.png" border="0" /></a>